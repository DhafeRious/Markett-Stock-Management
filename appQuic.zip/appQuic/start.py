#!/usr/bin/env python3

from application.application import main

if __name__ == '__main__':
	main()

